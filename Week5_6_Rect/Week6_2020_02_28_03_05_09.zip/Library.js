class Rectangle{
  constructor(x,y,w,h,r){
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.r = r;
  
  }

  show(){
  noStroke();
    fill(random(0,255))
  rect(this.x, this.y, this.w, this.h, this.r)
  
  }
}