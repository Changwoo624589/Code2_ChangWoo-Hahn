let rectangle;
let r = [];


function setup() {
  createCanvas(400, 400);
  for(let i = 0; i < 100; i++)
  r[i] = new Rectangle();

//noLoop();
}


function draw() {
 // noStroke();
  background(220);
  
  for(i= 0; i <random(10,100); i++){
    r[i] = new Rectangle(random(10,300),random(10,300),100,100,0);
    r[i].show();
    //print(i);
    //rectangle.draw(50,50,100,100,0)
  }
}