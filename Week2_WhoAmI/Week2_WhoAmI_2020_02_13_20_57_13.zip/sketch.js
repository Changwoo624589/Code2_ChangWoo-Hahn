let title = "Korean Food";
let foods = ["Bibimbap", "Bulgogi"]/*,"Kimchi"]*/
let ingredientsBibimbap = ["Rice"," Carrot", " Egg"]
let ingredientsBulgogi = ["Beef", " SoySauce"]
let ingredientsKimchi = ["Cabbage", " Red Pepper"]
var img = [];

function preload(){
  img[0] = loadImage('assets/Bibimbap.png');
  img[1] = loadImage('assets/Bulgogi.jpg');
  img[2] = loadImage('assets/Kimchi.jpg');
}

function setup() {
  
  createCanvas(600, 600);
  print(img[0].width + ' • ' + img[0].height);
  //noLoop();
}
function draw() {
  background(20);
  
  var x = mouseX;
  //print(x);
  textSize(40)
  fill(250)
  
  text(title, 20,39);
  
  if(x>=400){
    image(img[2], (x-400)*3, 50, 600, 400);
    textSize(35)
    fill(255/((x-400)*0.06));
    //text(foods[2], 20, 510);
    if(x<=600){
    foods.push("Kimchi");
    let result = foods.pop();
    text(result, 20, 510);
    textSize(25)
    let resultKimchi = ingredientsKimchi.join(", Ginger,");
    text(resultKimchi, 20, 550)
    }
  }
  else if (x<400)
  {
  image(img[2], 0, 50, 600, 400);
  }
  
  if(x>200)
  {
    image(img[1], (x-200)*3 , 50, 600, 400);
    textSize(35)
    fill(255/((x-200)*0.06));
    if(x<400){
    
    text(foods[1], 20, 510);
    textSize(25);
    text(ingredientsBulgogi.join(", Sugar,"), 20, 550);
    }
  }
  else if (x<=200)
  {
    image(img[1], 0, 50, 600, 400);
  }
  
  if(x<200)
  {
    image(img[0], x*3, 50, 600, 400);
    textSize(35)
    fill(255/(x*0.06));
    text(foods[0], 20, 510);
    textSize(25);
    text(ingredientsBibimbap, 20, 550);
  }
  
}