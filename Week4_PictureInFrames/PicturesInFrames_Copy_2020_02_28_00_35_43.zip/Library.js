
class Person{
  constructor(category, name){
  this.category = category;
  this.name = name;
  }
  
  draw(x,y){
    textSize(15)
    fill(0,0,250);
    text(this.category,x,y);
    text(this.name,x+130,y);
  }
  
  
}


