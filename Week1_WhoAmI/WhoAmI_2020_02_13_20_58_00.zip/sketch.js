var cont;
var img = [];
let button;
var x;
var speed;

function preload() {
  cont = loadJSON("cont.json");
  img[0] = loadImage('assets/Img_0.png');
  img[1] = loadImage('assets/Img_1.jpg');
  img[2] = loadImage('assets/Img_2.jpg');
  img[3] = loadImage('assets/Img_3.jpg');
}

function setup() {
  createCanvas(600, 660);
  //button = createButton('dd');
  //button.position(30, 30);
  //button.mousePressed(buttonAction);
  x = 0;
  speed =2.5;
  
}

function draw() {
  background(55, 90, 50);

  textSize(90);
  fill(255, 85)
  text(cont.hello, 165, 110);

  noStroke();
  fill(225);
  textSize(23);
  text(cont.content, 30, 180);

  //noStroke();
  noFill();
  stroke(random(0, 255), random(0, 255), random(0, 255));
  //fill(190, 135, 45);
  rectMode(CENTER);
  rect(300, 78, 580, 100, 10);
  
  rectMode(CORNER);
  stroke(30);
  fill(30);
  rect(0,300, 600, 463);
  
  
    noFill();
  stroke(255);
  //fill(190, 135, 45);
  rectMode(CENTER);
  rect(300, 335, 580, 60, 100);


  //RocketImg
  if(x>520){
  speed = -2.5
  }else if (x<5){
  speed = 2.5
  }
  x = x + speed;
  image(img[0], x, 300, 70, 70);

  if(x<90){
  image(img[1], 100, 370, 400, 285);
  }else if (x<400){
  image(img[2], 100, 370, 400, 285);
  }else if(x<520){
  image(img[3], 100, 370, 400, 285);
  }
}

function buttonAction() {
  let val = random(255);
  background(val);
}