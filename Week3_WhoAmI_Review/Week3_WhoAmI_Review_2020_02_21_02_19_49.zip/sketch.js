class Person{
  constructor(category, name){
  this.category = category;
  this.name = name;
  }
  
  draw(x,y){
    text(this.category,x,y);
    text(this.name,x+110,y);
  }
}

class Event{
  constructor(category, name){
  this.category = category;
  this.name = name;
  }
  
  draw(x,y){
    text(this.category,x,y);
    text(this.name,x+110,y);
  }
}
class Organization{
  constructor(category, name){
  this.category = category;
  this.name = name;
  }
  
  draw(x,y){
    text(this.category,x,y);
    text(this.name,x+110,y);
  }
}
class Location{
  constructor(category, name){
  this.category = category;
  this.name = name;
  }
  
  draw(x,y){
    text(this.category,x,y);
    text(this.name,x+110,y);
  }
}

let a;
let b;
let c;
let d;
var img = [];
var font;

function preload(){
  
  img[0] = loadImage('assets/img_0.jpg');
  img[1] = loadImage('assets/img_1.jpg');
  img[2] = loadImage('assets/img_2.jpg');
  font = loadFont('LeagueSpartan-Bold.otf');
}

function setup() {
  
  createCanvas(600, 600);

  
  a = new Person("Name:","Changwoo Hahn");
  b = new Event("Event:","Served Military");
  c = new Organization("Organization:","The New School");
  d = new Location("Location:","South Korea");
  
}

function draw() {
  noStroke();
  background(40);
  imgSlide();
  fill(250);
  textSize(15);
 

  a.draw(10,160);
  b.draw(10,180);
  c.draw(10, 200);
  d.draw(10, 220);
  //chang.draw(125,150);
  /*
  textFont(font);
  textSize(120);
  text('Hello', 10, 120);
  */

  var points = font.textToPoints('Hello', 10, 125, 130);
  for (var i =0; i < points.length; i++){
    var pt = points[i];
    stroke(200, 255,0);
    strokeWeight(random(1,6));
    point(pt.x, pt.y)

  }
}