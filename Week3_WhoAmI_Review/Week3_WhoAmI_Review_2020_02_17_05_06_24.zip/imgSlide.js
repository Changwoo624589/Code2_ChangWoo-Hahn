function imgSlide() { 
var x = mouseX;
  
  if(x>=400){
    image(img[2], (x-400)*3 + 50, 250, 500, 310);

    if(x<=600){


    }
  }
  else if (x<400)
  {
  image(img[2], 50, 250, 500, 310);
  }
  
  if(x>200)
  {
    image(img[1], (x-200)*3 +50, 250, 500, 310);
   

    if(x<400){
  
    }
  }
  else if (x<=200)
  {
    image(img[1], 0+50, 250, 500, 310);
  }
  
  if(x<200)
  {
    image(img[0], x*3+50, 250, 500, 310);
  }
}